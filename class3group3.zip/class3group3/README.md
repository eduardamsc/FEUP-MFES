# FEUP-MFES 2018/2019

Class 4MIEIC03 - Group 3

Element | College e-mail
--------|----------------
Daniel Filipe Santos Marques | up201503822@fe.up.pt
Maria Eduarda Santos Cunha | up201506524@fe.up.pt

Work developed for Formal Methods in Software Engineering (MFES).

## Project: ShopAdvizor
We developed a program in VDM++, using Overture, to create something similar to [ShopAdvizor](https://www.trialpanel.com/en/shopadvizor/) by TrialPanel. Essentially, we have users who can either submit their reviews regarding several products by a certain brand and retailer or who might just want to consult reviews done by others.
